import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.Reporter;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program which evaluates XMLTree expressions of {@code int}.
 *
 * @author Alex Desmarais
 *
 */
public final class XMLTreeNNExpressionEvaluator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeNNExpressionEvaluator() {
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static NaturalNumber evaluate(XMLTree exp) {
        String expLabel = exp.label();
        NaturalNumber value = new NaturalNumber2(0);
        //Checks if number tag, just the value
        if (expLabel.equals("number")) {
            int number = Integer.parseInt(exp.attributeValue("value"));
            if (number < 0) {
                Reporter.fatalErrorToConsole("Divide by zero");
            }
            value.setFromInt(number);
            //Computes addition
        } else if (expLabel.equals("plus")) {
            value.transferFrom(evaluate(exp.child(0)));
            value.add(evaluate(exp.child(1)));
            //Computes subtraction
        } else if (expLabel.equals("minus")) {
            //If difference negative, gives error
            value.transferFrom(evaluate(exp.child(0)));
            NaturalNumber subNumber = evaluate(exp.child(1));
            if (value.compareTo(subNumber) == -1) {
                Reporter.fatalErrorToConsole("Negative number subtract error");
            }
            value.subtract(subNumber);
            //Computes multiplication
        } else if (expLabel.equals("times")) {
            value.transferFrom(evaluate(exp.child(0)));
            value.multiply(evaluate(exp.child(1)));
            //Computes division
        } else if (expLabel.equals("divide")) {
            //Divide by 0 error
            value.transferFrom(evaluate(exp.child(0)));
            NaturalNumber divNumber = evaluate(exp.child(1));

            if (divNumber.compareTo(new NaturalNumber2(0)) == -1) {
                Reporter.fatalErrorToConsole("Divide by negative");
            }
            if (divNumber.compareTo(new NaturalNumber2(0)) == 0) {
                Reporter.fatalErrorToConsole("Divide by zero");
            }
            value.divide(divNumber);
        }
        return value;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}