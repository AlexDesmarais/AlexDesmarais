import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Alex Desmarais, Jacob Kim
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    @Test
    public final void testDefConstructor() {
        Set<String> s = this.constructorTest();
        Set<String> sExp = this.constructorRef();

        assertEquals(sExp, s);

    }

    @Test
    public final void testAddWithEmpty() {
        Set<String> s = this.constructorTest();
        Set<String> sExp = this.createFromArgsRef("word");

        s.add("word");

        assertEquals(sExp, s);

    }

    @Test
    public final void testAdd() {
        Set<String> s = this.createFromArgsTest("hello", "world");
        Set<String> sExp = this.createFromArgsRef("hello", "world", "word");

        s.add("word");

        assertEquals(sExp, s);

    }

    @Test
    public final void testAddLeft() {
        Set<String> s = this.createFromArgsTest("zebra", "yak", "wild");
        Set<String> sExp = this.createFromArgsRef("zebra", "yak", "wild",
                "xylophone");

        s.add("xylophone");

        assertEquals(sExp, s);
    }

    @Test
    public final void testAddRight() {
        Set<String> s = this.createFromArgsTest("animal", "banana", "cat");
        Set<String> sExp = this.createFromArgsRef("animal", "banana", "cat",
                "dog");

        s.add("dog");

        assertEquals(sExp, s);

    }

    @Test
    public final void testRemoveWithEmpty() {
        Set<String> s = this.createFromArgsTest("software");
        Set<String> sExp = this.createFromArgsRef();
        String rExp = "software";

        String r = s.remove("software");

        assertEquals(sExp, s);
        assertEquals(rExp, r);
    }

    @Test
    public final void testRemove() {
        Set<String> s = this.createFromArgsTest("red", "orange", "yellow",
                "green");
        Set<String> sExp = this.createFromArgsRef("red", "orange", "yellow");
        String rExp = "green";

        String r = s.remove("green");

        assertEquals(sExp, s);
        assertEquals(rExp, r);

    }

    @Test
    public final void testRemoveLeft() {
        Set<String> s = this.createFromArgsTest("red", "number", "color",
                "book");
        Set<String> sExp = this.createFromArgsRef("red", "number", "color");
        String rExp = "book";

        String r = s.remove("book");

        assertEquals(sExp, s);
        assertEquals(rExp, r);

    }

    @Test
    public final void testRemoveRight() {
        Set<String> s = this.createFromArgsTest("red", "riddle", "roll",
                "rule");
        Set<String> sExp = this.createFromArgsRef("riddle", "roll", "rule");
        String rExp = "red";

        String r = s.remove("red");

        assertEquals(sExp, s);
        assertEquals(rExp, r);
    }

    @Test
    public final void testRemoveAnyWithEmpty() {
        Set<String> s = this.createFromArgsTest("buckeye");
        Set<String> sExp = this.createFromArgsRef();
        String rExp = "buckeye";

        String r = s.removeAny();

        assertEquals(sExp, s);
        assertEquals(rExp, r);

    }

    @Test
    public final void testRemoveAny() {
        Set<String> s = this.createFromArgsTest("brutus", "buckeye", "ohio");
        Set<String> sExp = this.createFromArgsRef("brutus", "buckeye", "ohio");

        String r = s.removeAny();
        String rExp = sExp.remove(r);

        assertEquals(sExp, s);
        assertEquals(rExp, r);
    }

    @Test
    public final void testRemoveAnyLeft() {
        Set<String> s = this.createFromArgsTest("zamboni", "yoyo", "touchdown",
                "quarterback", "football");
        Set<String> sExp = this.createFromArgsRef("zamboni", "yoyo",
                "touchdown", "quarterback", "football");

        String r = s.removeAny();
        String rExp = sExp.remove(r);

        assertEquals(sExp, s);
        assertEquals(rExp, r);
    }

    @Test
    public final void testRemoveAnyRight() {
        Set<String> s = this.createFromArgsTest("awhile", "clock", "double",
                "epic", "football");
        Set<String> sExp = this.createFromArgsRef("awhile", "clock", "double",
                "epic", "football");

        String r = s.removeAny();
        String rExp = sExp.remove(r);

        assertEquals(sExp, s);
        assertEquals(rExp, r);
    }

    @Test
    public final void testContainsWithEmpty() {
        Set<String> s = this.constructorTest();
        Set<String> sExp = this.constructorRef();

        assertEquals(false, s.contains("osu"));
        assertEquals(sExp, s);

    }

    @Test
    public final void testContainsTrue() {
        Set<String> s = this.createFromArgsTest("lets", "go", "bucks");
        Set<String> sExp = this.createFromArgsRef("lets", "go", "bucks");

        assertEquals(true, s.contains("bucks"));
        assertEquals(sExp, s);

    }

    @Test
    public final void testContainsFalse() {
        Set<String> s = this.createFromArgsTest("lets", "go", "bucks");
        Set<String> sExp = this.createFromArgsRef("lets", "go", "bucks");

        assertEquals(false, s.contains("brutus"));
        assertEquals(sExp, s);

    }

    @Test
    public final void testSizeWithEmpty() {
        Set<String> s = this.constructorTest();
        Set<String> sExp = this.constructorRef();

        assertEquals(0, s.size());
        assertEquals(sExp, s);

    }

    @Test
    public final void testSizeSingle() {
        Set<String> s = this.createFromArgsTest("ohio");
        Set<String> sExp = this.createFromArgsRef("ohio");

        assertEquals(1, s.size());
        assertEquals(sExp, s);

    }

    @Test
    public final void testSizeMultiple() {
        Set<String> s = this.createFromArgsTest("ohio", "state", "buckeyes");
        Set<String> sExp = this.createFromArgsRef("ohio", "state", "buckeyes");

        assertEquals(3, s.size());
        assertEquals(sExp, s);

    }

}
