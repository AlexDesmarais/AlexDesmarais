import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * CSE 2221 - Program that calculates the closest estimation by the de Jager
 * formula.
 *
 * @author A.Desmarais
 *
 */
public final class ABCDGuesser2 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private ABCDGuesser2() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        //Initializes posInput so it can run in the While loop
        double posInput = -1;
        //A loop that asks for a positive real number and keeps going while negative
        while (posInput < 0) {
            out.print("Enter a positive real number: ");
            String strPosInput = in.nextLine();
            posInput = Double.parseDouble(strPosInput);
        }
        return posInput;

    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {
        //Initializes posDoubleInput so it can run the loop
        double posDoubleInput = -1;
        //A loop that asks for a positive real number greater than one until it gets it

        while (posDoubleInput < 0 && posDoubleInput != 1) {
            out.print("Enter a positive real number (not '1'): ");
            String strPosDoubleInput = in.nextLine();
            posDoubleInput = Double.parseDouble(strPosDoubleInput);
        }
        return posDoubleInput;
    }

    /**
     * Calculates the error for the final output. Simple method but will return
     * a crucial value. Returns the error from best guess to initial constant
     * inputed.
     *
     * @param hundred
     *            placeholder for 100
     * @param bestGuess
     *            closest estimation to constant value wanted found
     * @param constant
     *            constant input value
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return calculated error for output
     */
    private static double getFinalError(int hundred, double bestGuess,
            double constant, SimpleReader in, SimpleWriter out) {
        double error = (Math.abs((hundred - bestGuess) / constant));
        return error;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //Running the prompt methods
        double constant = getPositiveDouble(in, out);

        double w = getPositiveDoubleNotOne(in, out);
        double x = getPositiveDoubleNotOne(in, out);
        double y = getPositiveDoubleNotOne(in, out);
        double z = getPositiveDoubleNotOne(in, out);

        //Initializing constants
        final int hundred = 100;
        final double five = 5.0;
        final double four = 4.0;
        final double three = 3.0;
        final double two = 2.0;
        final double one = 1.0;
        final double zero = 0.0;
        //Array holding the constant exponent values
        double[] jagerArray = new double[] { (-five), (-four), (-three), (-two),
                (-one), (-(one / two)), (-(one / three)), (-(one / four)), zero,
                (one / four), (one / three), (one / two), one, two, three, four,
                five };
        //Initializing update variables
        double bestGuess = 0;

        double a = 0;
        double b = 0;
        double c = 0;
        double d = 0;
        //Beginning of calculation loop to find the closest attempt
        //Running w^a
        for (int counter1 = 0; counter1 < jagerArray.length; counter1++) {
            double wPowA = Math.pow(w, jagerArray[counter1]);

            //Running x^b
            for (int counter2 = 0; counter2 < jagerArray.length; counter2++) {
                double xPowB = Math.pow(x, jagerArray[counter2]);

                //Running y^c
                for (int counter3 = 0; counter3 < jagerArray.length; counter3++) {
                    double yPowC = Math.pow(y, jagerArray[counter3]);

                    //Running z^d
                    for (int counter4 = 0; counter4 < jagerArray.length; counter4++) {
                        double zPowD = Math.pow(z, jagerArray[counter4]);
                        //Performing the calculation in the equation
                        double currentGuess = wPowA * xPowB * yPowC * zPowD;
                        //Finding how close the current and best differences are
                        //to the constant
                        double currDiff = Math.abs(constant - currentGuess);
                        double bestDiff = Math.abs(constant - bestGuess);
                        //Setting the best guess of all the runs
                        if (currDiff < bestDiff) {
                            bestGuess = currentGuess;
                            //Initializing the a, b, c, d outputs
                            a = jagerArray[counter1];
                            b = jagerArray[counter2];
                            c = jagerArray[counter3];
                            d = jagerArray[counter4];
                        }
                    }
                }
            }

        }

        //Running the final output
        double finalError = getFinalError(hundred, bestGuess, constant, in,
                out);
        out.print("\nExponent Values: ");
        out.print("a=" + a);
        out.print(" b=" + b);
        out.print(" c=" + c);
        out.println(" d=" + d);

        out.print("Best estimate: ");
        out.println(bestGuess, 2, false);

        out.print("Relative Error: ");
        out.print(finalError, 2, false);
        out.print("%");

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
