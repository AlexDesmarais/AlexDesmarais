import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * @author Alex Desmarais
 *
 */
public class CryptoUtilitiesTest {

    /*
     * Tests of reduceToGCD
     */

    @Test
    public void testReduceToGCD_0_0() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(0);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    @Test
    public void testReduceToGCD_30_21() {
        NaturalNumber n = new NaturalNumber2(30);
        NaturalNumber nExpected = new NaturalNumber2(3);
        NaturalNumber m = new NaturalNumber2(21);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    /*
     * Tests of isEven
     */

    @Test
    public void testIsEven_0() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(0);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    @Test
    public void testIsEven_1() {
        NaturalNumber n = new NaturalNumber2(1);
        NaturalNumber nExpected = new NaturalNumber2(1);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * Tests of powerMod
     */

    @Test
    public void testPowerMod_0_0_2() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(0);
        NaturalNumber pExpected = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(2);
        NaturalNumber mExpected = new NaturalNumber2(2);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    @Test
    public void testPowerMod_17_18_19() {
        NaturalNumber n = new NaturalNumber2(17);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(18);
        NaturalNumber pExpected = new NaturalNumber2(18);
        NaturalNumber m = new NaturalNumber2(19);
        NaturalNumber mExpected = new NaturalNumber2(19);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * My Tests Written - Extra
     */

    /**
     * Test reduceToGCD with greater numbers, second number greater (routine)
     */

    @Test
    public void testReduceToGCD_48_64() {
        NaturalNumber n = new NaturalNumber2(48);
        NaturalNumber nExpected = new NaturalNumber2(16);
        NaturalNumber m = new NaturalNumber2(64);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);

    }

    /**
     * Test reduceToGCD with much greater numbers (triple digits) (boundary)
     */

    @Test
    public void testReduceToGCD_128_64() {
        NaturalNumber n = new NaturalNumber2(128);
        NaturalNumber nExpected = new NaturalNumber2(64);
        NaturalNumber m = new NaturalNumber2(64);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);

    }

    /**
     * Test isEven with a large even number (boundary)
     */

    @Test
    public void testIsEven_154000() {
        NaturalNumber n = new NaturalNumber2(154000);
        NaturalNumber nExpected = new NaturalNumber2(154000);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);

    }

    /**
     * Test isEven with a large odd number (boundary)
     */

    @Test
    public void testIsEven_154001() {
        NaturalNumber n = new NaturalNumber2(154001);
        NaturalNumber nExpected = new NaturalNumber2(154001);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);

    }

    /**
     * Test powerMod with numbers in the triple digits
     */

    @Test
    public void testPowerMod_99_100_101() {
        NaturalNumber n = new NaturalNumber2(99);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(100);
        NaturalNumber pExpected = new NaturalNumber2(100);
        NaturalNumber m = new NaturalNumber2(101);
        NaturalNumber mExpected = new NaturalNumber2(101);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);

    }

    /**
     * Test isWitnessToCompositeness with low possible values
     */

    @Test
    public void testIsWitnessToCompositeness_2_9() {
        NaturalNumber two = new NaturalNumber2(2);
        NaturalNumber nine = new NaturalNumber2(9);
        boolean result = CryptoUtilities.isWitnessToCompositeness(two, nine);
        assertEquals(false, result);
    }

    /**
     * Test isWitnessToCompositeness with high possible values
     */

    @Test
    public void testIsWitnessToCompositeness_150_162() {
        NaturalNumber oneFiftyThous = new NaturalNumber2(1500);
        NaturalNumber oneSixtyTwoThous = new NaturalNumber2(1620);
        boolean result = CryptoUtilities.isWitnessToCompositeness(oneFiftyThous,
                oneSixtyTwoThous);
        assertEquals(false, result);
    }

    /**
     * Test isPrime1 with low possible prime value
     */

    @Test
    public void testIsPrime1_3() {
        NaturalNumber three = new NaturalNumber2(3);
        boolean result = CryptoUtilities.isPrime1(three);
        assertEquals(true, result);
    }

    /**
     * Test isPrime1 with high possible non-prime value
     */

    @Test
    public void testIsPrime1_122() {
        NaturalNumber onetwentytwo = new NaturalNumber2(122);
        boolean result = CryptoUtilities.isPrime1(onetwentytwo);
        assertEquals(false, result);
    }

    /**
     * Test isPrime2 with low possible prime value
     */

    @Test
    public void testIsPrime2_5() {
        NaturalNumber five = new NaturalNumber2(5);
        boolean result = CryptoUtilities.isPrime2(five);
        assertEquals(true, result);
    }

    /**
     * Test isPrime2 with high possible non-prime value
     */

    @Test
    public void testIsPrime2_120() {
        NaturalNumber onetwenty = new NaturalNumber2(120);
        boolean result = CryptoUtilities.isPrime2(onetwenty);
        assertEquals(false, result);
    }

    /**
     * Test generateNextLikelyPrime with low possible value
     */

    @Test
    public void testGenerateNextLikelyPrime_5() {
        NaturalNumber five = new NaturalNumber2(5);
        NaturalNumber expected = new NaturalNumber2(7);
        CryptoUtilities.generateNextLikelyPrime(five);
        assertEquals(expected, five);
    }

    /**
     * Test generateNextLikelyPrime with high possible value
     */

    @Test
    public void testGenerateNextLikelyPrime_149() {
        NaturalNumber onefortynine = new NaturalNumber2(149);
        NaturalNumber expected = new NaturalNumber2(151);
        CryptoUtilities.generateNextLikelyPrime(onefortynine);
        assertEquals(expected, onefortynine);
    }

}