import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Project: Compute Roots Using Newton Iteration - CSE 2221.
 *
 * @author A. Desmarais
 *
 */
public final class Newton2 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Newton2() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number to compute square root of
     * @return estimate of square root
     */
    private static double sqrt(double x) {
        if (x == 0) {
            return 0;
        }

        double num = x;
        final double half = 0.5;
        final double tolerance = 0.0001;
        while (Math.abs((num * num) - x) / x > tolerance) {
            num = (half) * (num + x / num);
        }
        return num;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Would you like to calculate a square root? "
                + "(Enter 'y' for yes, anything else for no)");
        String response = in.nextLine();
        if (response.equalsIgnoreCase("y")) {
            out.print("Enter a positive number: ");
            double numInput = in.nextDouble();
            double rootF = sqrt(numInput);
            out.print("The square root of " + numInput + " is " + rootF);
        }

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
